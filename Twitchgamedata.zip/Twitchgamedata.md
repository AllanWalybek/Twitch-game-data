```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.style as style
import seaborn as sns
import itertools
%matplotlib inline
from matplotlib import figure
import folium
from pylab import rcParams
from datetime import datetime
```


```python
import warnings
warnings.filterwarnings('ignore')
```


```python
df = pd.read_csv('./data/Twitch_game_data.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Game</th>
      <th>Month</th>
      <th>Year</th>
      <th>Hours_watched</th>
      <th>Hours_Streamed</th>
      <th>Peak_viewers</th>
      <th>Peak_channels</th>
      <th>Streamers</th>
      <th>Avg_viewers</th>
      <th>Avg_channels</th>
      <th>Avg_viewer_ratio</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>League of Legends</td>
      <td>1</td>
      <td>2016</td>
      <td>94377226</td>
      <td>1362044 hours</td>
      <td>530270</td>
      <td>2903</td>
      <td>129172</td>
      <td>127021</td>
      <td>1833</td>
      <td>69.29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Counter-Strike: Global Offensive</td>
      <td>1</td>
      <td>2016</td>
      <td>47832863</td>
      <td>830105 hours</td>
      <td>372654</td>
      <td>2197</td>
      <td>120849</td>
      <td>64378</td>
      <td>1117</td>
      <td>57.62</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Dota 2</td>
      <td>1</td>
      <td>2016</td>
      <td>45185893</td>
      <td>433397 hours</td>
      <td>315083</td>
      <td>1100</td>
      <td>44074</td>
      <td>60815</td>
      <td>583</td>
      <td>104.26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Hearthstone</td>
      <td>1</td>
      <td>2016</td>
      <td>39936159</td>
      <td>235903 hours</td>
      <td>131357</td>
      <td>517</td>
      <td>36170</td>
      <td>53749</td>
      <td>317</td>
      <td>169.29</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Call of Duty: Black Ops III</td>
      <td>1</td>
      <td>2016</td>
      <td>16153057</td>
      <td>1151578 hours</td>
      <td>71639</td>
      <td>3620</td>
      <td>214054</td>
      <td>21740</td>
      <td>1549</td>
      <td>14.03</td>
    </tr>
  </tbody>
</table>
</div>




```python
dfRank=df[df['Rank']==1].Game.value_counts()
ax=sns.barplot(x=dfRank.values, y=dfRank.index)
```


    
![png](output_4_0.png)
    



```python
dfTotalWatch = df.groupby('Game').Hours_watched.sum().sort_values(ascending=False)
dfTotalWatch = dfTotalWatch[0:10]
ax=sns.barplot(x=dfTotalWatch.values, y=dfTotalWatch.index)
```


    
![png](output_5_0.png)
    



```python
dfWatch=df[df['Game'].isin(dfTotalWatch.index)]
fig,ax=plt.subplots(figsize=(9, 6))
sns.lineplot(ax=ax,data=dfWatch, x="Date", y="Hours_watched",hue="Game",linewidth = 2)
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_36008/4226362434.py in <module>
          1 dfWatch=df[df['Game'].isin(dfTotalWatch.index)]
          2 fig,ax=plt.subplots(figsize=(9, 6))
    ----> 3 sns.lineplot(ax=ax,data=dfWatch, x="Date", y="Hours_watched",hue="Game",linewidth = 2)
    

    ~\anaconda3\lib\site-packages\seaborn\_decorators.py in inner_f(*args, **kwargs)
         44             )
         45         kwargs.update({k: arg for k, arg in zip(sig.parameters, args)})
    ---> 46         return f(**kwargs)
         47     return inner_f
         48 
    

    ~\anaconda3\lib\site-packages\seaborn\relational.py in lineplot(x, y, hue, size, style, data, palette, hue_order, hue_norm, sizes, size_order, size_norm, dashes, markers, style_order, units, estimator, ci, n_boot, seed, sort, err_style, err_kws, legend, ax, **kwargs)
        690 
        691     variables = _LinePlotter.get_semantics(locals())
    --> 692     p = _LinePlotter(
        693         data=data, variables=variables,
        694         estimator=estimator, ci=ci, n_boot=n_boot, seed=seed,
    

    ~\anaconda3\lib\site-packages\seaborn\relational.py in __init__(self, data, variables, estimator, ci, n_boot, seed, sort, err_style, err_kws, legend)
        365         )
        366 
    --> 367         super().__init__(data=data, variables=variables)
        368 
        369         self.estimator = estimator
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in __init__(self, data, variables)
        603     def __init__(self, data=None, variables={}):
        604 
    --> 605         self.assign_variables(data, variables)
        606 
        607         for var, cls in self._semantic_mappings.items():
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in assign_variables(self, data, variables)
        666         else:
        667             self.input_format = "long"
    --> 668             plot_data, variables = self._assign_variables_longform(
        669                 data, **variables,
        670             )
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in _assign_variables_longform(self, data, **kwargs)
        901 
        902                 err = f"Could not interpret value `{val}` for parameter `{key}`"
    --> 903                 raise ValueError(err)
        904 
        905             else:
    

    ValueError: Could not interpret value `Date` for parameter `x`



    
![png](output_6_1.png)
    



```python
sns.scatterplot(x = "Avg_viewers", y = "streamers", 
                hue = "year", 
                data = df);
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    ~\AppData\Local\Temp/ipykernel_36008/2529631239.py in <module>
    ----> 1 sns.scatterplot(x = "Avg_viewers", y = "streamers", 
          2                 hue = "year",
          3                 data = df);
    

    ~\anaconda3\lib\site-packages\seaborn\_decorators.py in inner_f(*args, **kwargs)
         44             )
         45         kwargs.update({k: arg for k, arg in zip(sig.parameters, args)})
    ---> 46         return f(**kwargs)
         47     return inner_f
         48 
    

    ~\anaconda3\lib\site-packages\seaborn\relational.py in scatterplot(x, y, hue, style, size, data, palette, hue_order, hue_norm, sizes, size_order, size_norm, markers, style_order, x_bins, y_bins, units, estimator, ci, n_boot, alpha, x_jitter, y_jitter, legend, ax, **kwargs)
        806 
        807     variables = _ScatterPlotter.get_semantics(locals())
    --> 808     p = _ScatterPlotter(
        809         data=data, variables=variables,
        810         x_bins=x_bins, y_bins=y_bins,
    

    ~\anaconda3\lib\site-packages\seaborn\relational.py in __init__(self, data, variables, x_bins, y_bins, estimator, ci, n_boot, alpha, x_jitter, y_jitter, legend)
        585         )
        586 
    --> 587         super().__init__(data=data, variables=variables)
        588 
        589         self.alpha = alpha
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in __init__(self, data, variables)
        603     def __init__(self, data=None, variables={}):
        604 
    --> 605         self.assign_variables(data, variables)
        606 
        607         for var, cls in self._semantic_mappings.items():
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in assign_variables(self, data, variables)
        666         else:
        667             self.input_format = "long"
    --> 668             plot_data, variables = self._assign_variables_longform(
        669                 data, **variables,
        670             )
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in _assign_variables_longform(self, data, **kwargs)
        901 
        902                 err = f"Could not interpret value `{val}` for parameter `{key}`"
    --> 903                 raise ValueError(err)
        904 
        905             else:
    

    ValueError: Could not interpret value `streamers` for parameter `y`



```python

```


```python

```
